USE [StoreInventory];

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF EXISTS(SELECT 1 from sys.procedures where name = 'AddModifyInventoryItem')
DROP PROCEDURE AddModifyInventoryItem;

GO
CREATE PROCEDURE AddModifyInventoryItem
@item_name VARCHAR(MAX),
@description [varchar](max),
@price [numeric](19, 12),
@quantity [int],
@discount [numeric](19, 12),
@item_code int,
@is_insert BIT
AS
BEGIN
	DECLARE @error VARCHAR(max)
	SET NOCOUNT ON;
	BEGIN TRAN
		BEGIN TRY
		IF(@is_insert = 1)
		   INSERT INTO StoreInventory.dbo.inventory_item( item_name,[description],price,quantity,discount,created_on,modified_on)
		   VALUES (@item_name,@description,@price,@quantity,@discount,GETDATE(),GETDATE())
	   ELSE
	   BEGIN
	   IF EXISTS(SELECT 1 from StoreInventory.dbo.[inventory_item] where item_code = @item_code)
		  UPDATE StoreInventory.dbo.inventory_item 
		   SET item_name = @item_name,description = @description,discount =@discount,price = @price,quantity = @quantity
		   WHERE item_code = @item_code
		ELSE
			SELECT 'Item does not exists.' as [error_message]
		 
		END
		   COMMIT
		   END TRY
		   BEGIN CATCH
			   ROLLBACK
			   SET @error =ISNULL(ERROR_MESSAGE(),'') 
			   RAISERROR(@error,16,1)
		   END CATCH

END
GO
