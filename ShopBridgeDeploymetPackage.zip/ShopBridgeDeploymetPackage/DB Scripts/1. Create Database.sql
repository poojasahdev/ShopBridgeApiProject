
IF NOT EXISTS(Select 1 from sys.databases where name = 'StoreInventory')
BEGIN
Create database StoreInventory;
END

USE [StoreInventory]
GO

/****** Object:  Table [dbo].[inventory_item]    Script Date: 29-07-2021 19:01:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS(SELECT 1 from INFORMATION_SCHEMA.TABLES where TABLE_NAME = 'inventory_item')

CREATE TABLE [dbo].[inventory_item](
	[item_code] [int] IDENTITY(1,1) PRIMARY KEY,
	[item_name] [varchar](max) NOT NULL,
	[description] [varchar](max) NULL,
	[price] [numeric](9, 3) NOT NULL,
	[quantity] [int] NOT NULL DEFAULT 0,
	[discount] [numeric](9, 3) NULL,
	[created_on] [datetime] DEFAULT GETDATE(),
	[modified_on] [datetime] DEFAULT GETDATE()
)

GO

SET ANSI_PADDING OFF
GO


