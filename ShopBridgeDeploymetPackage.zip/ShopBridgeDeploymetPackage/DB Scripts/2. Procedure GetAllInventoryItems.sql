USE [StoreInventory];

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF EXISTS(SELECT 1 from sys.procedures where name = 'GetAllInventoryItems')
DROP PROCEDURE GetAllInventoryItems;

GO
CREATE PROCEDURE GetAllInventoryItems

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   Select item_code,item_name,[description],price,quantity,discount from StoreInventory.dbo.[inventory_item];

END
GO
