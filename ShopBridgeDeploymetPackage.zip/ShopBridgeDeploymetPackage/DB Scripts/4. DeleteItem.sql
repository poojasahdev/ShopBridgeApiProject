USE [StoreInventory];

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF EXISTS(SELECT 1 from sys.procedures where name = 'DeleteItem')
DROP PROCEDURE DeleteItem;

GO
CREATE PROCEDURE DeleteItem
@item_code int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF EXISTS(SELECT 1 from StoreInventory.dbo.[inventory_item] where item_code = @item_code)
		DELETE from StoreInventory.dbo.[inventory_item] where item_code = @item_code;
	ELSE
		SELECT 'Item does not exists.' as [error_message]

END
GO
